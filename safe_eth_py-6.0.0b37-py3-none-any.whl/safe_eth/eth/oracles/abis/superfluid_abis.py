super_token_abi = [
    {
        "inputs": [],
        "name": "getUnderlyingToken",
        "outputs": [{"internalType": "address", "name": "", "type": "address"}],
        "stateMutability": "view",
        "type": "function",
    },
]
